export type RequestConfigType = {
  signal?: AbortSignal | null;
};
